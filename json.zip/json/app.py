from flask import Flask, render_template, request
import json
import os

app = Flask(__name__)

DATA_FOLDER = "data"

if not os.path.exists(DATA_FOLDER):
    os.makedirs(DATA_FOLDER)


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")


@app.route("/save", methods=["POST"])
def save():
    nom = request.form.get("nom", "").strip()
    prenom = request.form.get("prenom", "").strip()

    if not nom or not prenom:
        return render_template("index.html", error="Veuillez remplir le nom et le prénom.")

    person = {
        "nom": nom,
        "prenom": prenom
    }

    filename = f"{prenom}_{nom}.json"
    filepath = os.path.join(DATA_FOLDER, filename)

    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(person, f, indent=4, ensure_ascii=False)

    return render_template("index.html", success=f"Fichier {filename} créé avec succès !")


if __name__ == "__main__":
    app.run(debug=True)